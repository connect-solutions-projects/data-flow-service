# Modelos e Templates

Repositório de modelos reutilizáveis.

- `modelo-relatorio-final.md` – estrutura base para produção de relatórios finais.

Inclua aqui quaisquer novos templates (planilhas, apresentações, documentos) necessários para futuras entregas.
